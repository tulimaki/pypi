# This file is part of Shoop.
#
# Copyright (c) 2012-2015, Shoop Ltd. All rights reserved.
#
# This source code is licensed under the AGPLv3 license found in the
# LICENSE file in the root directory of this source tree.
#                       ___
#                    .-'   `'.
#                   /         \
#                   |         ;
#                   |         |           ___.--,
#          _.._     |0) ~ (0) |    _.---'`__.-( (_.
#   __.--'`_.. '.__.\    '--. \_.-' ,.--'`     `""`
#  ( ,.--'`   ',__ /./;   ;, '.__.'`    __
#  _`) )  .---.__.' / |   |\   \__..--""  """--.,_
# `---' .'.''-._.-'`_./  /\ '.  \ _.-~~~````~~~-._`-.__.'
#       | |  .' _.-' |  |  \  \  '.               `~---`
#        \ \/ .'     \  \   '. '-._)
#         \/ /        \  \    `=.__`~-.
#    jgs  / /\         `) )    / / `"".`\
#   , _.-'.'\ \        / /    ( (     / /
#    `--~`   ) )    .-'.'      '.'.  | (
#           (/`    ( (`          ) )  '-;
#            `      '-;         (-'
#
