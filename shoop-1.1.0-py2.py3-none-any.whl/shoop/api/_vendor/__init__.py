# TODO: Remove `_vendor` once parler_rest>=1.2 is released
