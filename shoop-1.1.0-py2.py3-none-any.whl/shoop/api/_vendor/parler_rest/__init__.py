# -*- coding: utf-8 -*-
"""This package provides support for integrating translatable fields into *django-rest-framework*."""
# following PEP 440
__version__ = "1.3a1"
