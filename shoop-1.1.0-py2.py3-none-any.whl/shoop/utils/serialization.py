# -*- coding: utf-8 -*-
# This file is part of Shoop.
#
# Copyright (c) 2012-2015, Shoop Ltd. All rights reserved.
#
# This source code is licensed under the AGPLv3 license found in the
# LICENSE file in the root directory of this source tree.

import django.core.serializers.json
from django.utils.encoding import force_text
from django.utils.functional import Promise


class ExtendedJSONEncoder(django.core.serializers.json.DjangoJSONEncoder):
    def default(self, o):
        if isinstance(o, Promise):
            return force_text(o)
        return super(ExtendedJSONEncoder, self).default(o)
