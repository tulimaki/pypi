# -*- coding: utf-8 -*-
# This file is part of Shoop.
#
# Copyright (c) 2012-2015, Shoop Ltd. All rights reserved.
#
# This source code is licensed under the AGPLv3 license found in the
# LICENSE file in the root directory of this source tree.

import pytest
from shoop.core.models import Product
from shoop.core.utils.product_caching_object import ProductCachingObject
from shoop.testing.factories import get_default_shop_product, create_product


def test_product_caching_object_nulling():
    pco = ProductCachingObject()
    pco.product = None
    assert not pco.product
    assert not pco.product_id

    pco = ProductCachingObject()
    pco.product = None
    assert not pco.product_id

    pco = ProductCachingObject()
    pco.product_id = None
    assert not pco.product


def test_product_caching_object_type_validation():
    with pytest.raises(TypeError):
        pco = ProductCachingObject()
        pco.product_id = "yeah"

    with pytest.raises(TypeError):
        pco = ProductCachingObject()
        pco.product = "yeahhh"

    with pytest.raises(ValueError):
        pco = ProductCachingObject()
        pco.product = Product()


@pytest.mark.django_db
def test_product_caching_object():
    shop_product = get_default_shop_product()
    product = shop_product.product
    another_product = create_product("PCOTestProduct")

    pco = ProductCachingObject()
    pco.product = product
    assert pco.product is product
    assert pco.product_id == product.pk
    assert ProductCachingObject().product != pco.product  # Assert PCOs are separate
    assert pco._product_cache == pco.product  # This private property is courtesy of ModelCachingDescriptor

    pco = ProductCachingObject()
    pco.product_id = product.pk
    assert pco.product == product
    assert pco.product_id == product.pk

    # Not creating a new PCO here
    pco.product = another_product
    assert pco.product == another_product
    assert pco.product_id == another_product.pk

    # Nor here
    pco.product_id = product.pk
    assert pco.product == product
    assert pco.product_id == product.pk
