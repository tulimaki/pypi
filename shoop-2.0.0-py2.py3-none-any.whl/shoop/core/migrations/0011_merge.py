# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('shoop', '0010_fk_on_delete'),
        ('shoop', '0010_tax_field_verbose_names'),
    ]

    operations = [
    ]
